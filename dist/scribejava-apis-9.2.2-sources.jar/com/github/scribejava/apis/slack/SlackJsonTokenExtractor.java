/*
 * The MIT License
 *
 * Copyright (c) 2010 Pablo Fernandez
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.github.scribejava.apis.slack;

import com.github.scribejava.core.extractors.OAuth2AccessTokenJsonExtractor;
import com.github.scribejava.core.model.JsonObject;
import com.github.scribejava.core.model.OAuth2AccessToken;
import java.util.Map;

/** Extracteur JSON pour Slack (Supporte les champs additionnels). */
public class SlackJsonTokenExtractor extends OAuth2AccessTokenJsonExtractor {

  protected SlackJsonTokenExtractor() {}

  public static SlackJsonTokenExtractor instance() {
    return InstanceHolder.INSTANCE;
  }

  @Override
  protected OAuth2AccessToken createToken(
      String accessToken,
      String tokenType,
      Integer expiresIn,
      String refreshToken,
      String scope,
      JsonObject json,
      String rawResponse) {

    final Map<String, Object> authedUser = json.getMap("authed_user");
    String userAccessToken = null;
    if (authedUser != null) {
      userAccessToken = (String) authedUser.get("access_token");
    }

    return new SlackOAuth2AccessToken(
        accessToken, tokenType, expiresIn, refreshToken, scope, userAccessToken, rawResponse);
  }

  private static class InstanceHolder {
    private static final SlackJsonTokenExtractor INSTANCE = new SlackJsonTokenExtractor();
  }
}
