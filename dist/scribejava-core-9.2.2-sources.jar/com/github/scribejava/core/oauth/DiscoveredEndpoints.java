/*
 * The MIT License
 *
 * Copyright (c) 2010 Pablo Fernandez
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.github.scribejava.core.oauth;

/** Représente les points de terminaison (endpoints) découverts via un service de découverte. */
public class DiscoveredEndpoints {
  private final String authorizationEndpoint;
  private final String tokenEndpoint;

  /**
   * Constructeur.
   *
   * @param authorizationEndpoint L'URL du point de terminaison d'autorisation.
   * @param tokenEndpoint L'URL du point de terminaison de jeton.
   */
  public DiscoveredEndpoints(String authorizationEndpoint, String tokenEndpoint) {
    this.authorizationEndpoint = authorizationEndpoint;
    this.tokenEndpoint = tokenEndpoint;
  }

  /**
   * @return L'URL du point de terminaison d'autorisation.
   */
  public String getAuthorizationEndpoint() {
    return authorizationEndpoint;
  }

  /**
   * @return L'URL du point de terminaison de jeton.
   */
  public String getTokenEndpoint() {
    return tokenEndpoint;
  }
}
