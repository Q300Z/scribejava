/*
 * The MIT License
 *
 * Copyright (c) 2010 Pablo Fernandez
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.github.scribejava.core.pkce;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Utilisé pour implémenter PKCE (Proof Key for Code Exchange) par les clients publics OAuth.
 *
 * @see <a href="https://tools.ietf.org/html/rfc7636">RFC 7636</a>
 */
public class PKCEService {

  private static final SecureRandom RANDOM = new SecureRandom();

  /** Nombre d'octets à générer aléatoirement. */
  private final int numberOFOctets;

  /**
   * Constructeur avec nombre d'octets spécifique.
   *
   * @param numberOFOctets Le nombre d'octets pour l'entropie.
   */
  public PKCEService(int numberOFOctets) {
    this.numberOFOctets = numberOFOctets;
  }

  /**
   * Crée un générateur avec les paramètres recommandés (32 octets).
   *
   * @see <a href="https://tools.ietf.org/html/rfc7636#section-4.1">RFC 7636, Section 4.1</a>
   */
  public PKCEService() {
    this(32);
  }

  /**
   * @return L'instance par défaut de {@link PKCEService}.
   */
  public static PKCEService defaultInstance() {
    return DefaultInstanceHolder.INSTANCE;
  }

  /**
   * Génère un nouvel objet PKCE complet (verifier et challenge).
   *
   * @return Une instance de {@link PKCE}.
   */
  public PKCE generatePKCE() {
    final byte[] bytes = new byte[numberOFOctets];
    RANDOM.nextBytes(bytes);
    return generatePKCE(bytes);
  }

  /**
   * Génère un objet PKCE à partir d'octets aléatoires fournis.
   *
   * @param randomBytes Octets d'entropie.
   * @return Une instance de {@link PKCE}.
   */
  public PKCE generatePKCE(byte[] randomBytes) {
    final String codeVerifier = Base64.getUrlEncoder().withoutPadding().encodeToString(randomBytes);

    final PKCE pkce = new PKCE();
    pkce.setCodeVerifier(codeVerifier);
    try {
      pkce.setCodeChallenge(pkce.getCodeChallengeMethod().transform2CodeChallenge(codeVerifier));
    } catch (NoSuchAlgorithmException nsaE) {
      pkce.setCodeChallengeMethod(PKCECodeChallengeMethod.PLAIN);
      try {
        pkce.setCodeChallenge(PKCECodeChallengeMethod.PLAIN.transform2CodeChallenge(codeVerifier));
      } catch (NoSuchAlgorithmException unrealE) {
        throw new IllegalStateException("It's just cannot be", unrealE);
      }
    }
    return pkce;
  }

  private static class DefaultInstanceHolder {

    private static final PKCEService INSTANCE = new PKCEService();
  }
}
