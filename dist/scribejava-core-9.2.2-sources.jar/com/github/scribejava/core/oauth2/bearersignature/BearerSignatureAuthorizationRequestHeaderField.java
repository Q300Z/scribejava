/*
 * The MIT License
 *
 * Copyright (c) 2010 Pablo Fernandez
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.github.scribejava.core.oauth2.bearersignature;

import com.github.scribejava.core.model.OAuthConstants;
import com.github.scribejava.core.model.OAuthRequest;

/**
 * 2.1. Authorization Request Header Field <br>
 * <a href="https://tools.ietf.org/html/rfc6750#section-2.1">...</a>
 */
public class BearerSignatureAuthorizationRequestHeaderField implements BearerSignature {

  protected BearerSignatureAuthorizationRequestHeaderField() {}

  /**
   * Retourne l'instance unique (singleton) de ce type de signature.
   *
   * @return L'instance de {@link BearerSignatureAuthorizationRequestHeaderField}.
   */
  public static BearerSignatureAuthorizationRequestHeaderField instance() {
    return InstanceHolder.INSTANCE;
  }

  @Override
  public void signRequest(String accessToken, OAuthRequest request) {
    request.addHeader(OAuthConstants.HEADER, "Bearer " + accessToken);
  }

  private static class InstanceHolder {

    private static final BearerSignatureAuthorizationRequestHeaderField INSTANCE =
        new BearerSignatureAuthorizationRequestHeaderField();
  }
}
