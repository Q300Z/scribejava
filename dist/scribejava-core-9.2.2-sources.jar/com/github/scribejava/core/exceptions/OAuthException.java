/*
 * The MIT License
 *
 * Copyright (c) 2010 Pablo Fernandez
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.github.scribejava.core.exceptions;

/** Default ScribeJava exception. Represents a problem in the OAuth signing process */
public class OAuthException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  /**
   * Default constructor
   *
   * @param message message explaining what went wrong
   * @param e original exception
   */
  public OAuthException(String message, Exception e) {
    super(message, e);
  }

  /**
   * No-exception constructor. Used when there is no original exception
   *
   * @param message message explaining what went wrong
   */
  public OAuthException(String message) {
    super(message, null);
  }

  /**
   * Exception constructor. Used to simply wrap an exception.
   *
   * @param e original exception
   */
  public OAuthException(Exception e) {
    super(e);
  }
}
