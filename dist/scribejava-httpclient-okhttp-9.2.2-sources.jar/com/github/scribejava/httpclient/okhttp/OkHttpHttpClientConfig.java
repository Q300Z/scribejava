/*
 * The MIT License
 *
 * Copyright (c) 2010 Pablo Fernandez
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.github.scribejava.httpclient.okhttp;

import com.github.scribejava.core.httpclient.HttpClientConfig;
import okhttp3.OkHttpClient;

/** Configuration pour le client HTTP OkHttp. */
public class OkHttpHttpClientConfig implements HttpClientConfig {

  private final OkHttpClient.Builder clientBuilder;

  /**
   * Constructeur.
   *
   * @param clientBuilder Le constructeur de client OkHttp.
   */
  public OkHttpHttpClientConfig(OkHttpClient.Builder clientBuilder) {
    this.clientBuilder = clientBuilder;
  }

  /**
   * Crée une configuration par défaut.
   *
   * @return Une instance de {@link OkHttpHttpClientConfig}.
   */
  public static OkHttpHttpClientConfig defaultConfig() {
    return new OkHttpHttpClientConfig(null);
  }

  /**
   * Retourne le constructeur de client OkHttp.
   *
   * @return Le {@link okhttp3.OkHttpClient.Builder}.
   */
  public OkHttpClient.Builder getClientBuilder() {
    return clientBuilder;
  }
}
